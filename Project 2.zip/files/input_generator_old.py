import os

def generate_garage_input():
    # ==========================================
    # 1. DEFINE THE GARAGE STATE
    # ==========================================
    
    # Mechanics: Tuples of (Mechanic_ID, Fatigue_Limit_k)
    mechanics = [
        (1, 3),
        (2, 6),
        (3, 4),
        (4, 2),
        (5, 5)
    ]

    # Car Types (DAG Blueprints): 
    # Dictionary mapping Car_Type_ID -> {"total_tasks": int, "edges": [(from, to, prob), ...]}
    car_types = {
        1: {
            "total_tasks": 4,
            "edges": [
                (1, 2, 0.0),
                (1, 3, 0.2),
                (2, 4, 0.5),
                (3, 4, 0.0)
            ]
        },
        2: {
            "total_tasks": 2,
            "edges": [
                (1, 2, 0.8)
            ]
        },
        3: {
            "total_tasks": 3,
            "edges": [
                (1, 2, 0.3),
                (2, 3, 0.1)
            ]
        }
    }

    # Daily Queue: Tuples of (Car_Type_ID, Quantity)
    daily_queue = [
        (1, 2),
        (2, 0),
        (3, 4)
    ]

    # ==========================================
    # 2. BUILD THE OUTPUT STRING
    # ==========================================
    output_lines = []

    output_lines.append("% --- MECHANICS ---")
    output_lines.append("% Format: M <MechanicID> <FatigueLimit_k>")
    for mech_id, k in mechanics:
        output_lines.append(f"M {mech_id} {k}")
    
    output_lines.append("\n% --- CAR TYPE DEFINITIONS (The DAGs) ---")
    output_lines.append("% Format for defining a car: T <CarTypeID> <TotalBaselineTasks>")
    output_lines.append("% Format for defining dependencies: E <CarTypeID> <FromTaskNode> <ToTaskNode> <SpawnProbability>")
    
    for car_id, data in car_types.items():
        output_lines.append(f"\nT {car_id} {data['total_tasks']}")
        for edge in data["edges"]:
            output_lines.append(f"E {car_id} {edge[0]} {edge[1]} {edge[2]}")

    output_lines.append("\n% --- DAILY QUEUE (Today's Workload) ---")
    output_lines.append("% Format: N <CarTypeID> <Quantity>")
    for car_id, quantity in daily_queue:
        output_lines.append(f"N {car_id} {quantity}")

    # Combine into a single string
    final_output_string = "\n".join(output_lines)
    return final_output_string

def main():
    # 1. Generate the content
    file_content = generate_garage_input()
    
    # 2. Define the output filename
    output_filename = "garage_input.txt"
    
    # 3. Print to Terminal
    print("==================================================")
    print(f" GENERATING INPUT FILE: {output_filename}")
    print("==================================================\n")
    print(file_content)
    print("\n==================================================")
    
    # 4. Write to File
    try:
        with open(output_filename, "w") as file:
            file.write(file_content)
        print(f"[SUCCESS] Successfully saved to '{os.path.abspath(output_filename)}'")
    except IOError as e:
        print(f"[ERROR] Failed to write to file: {e}")

if __name__ == "__main__":
    main()